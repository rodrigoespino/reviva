<div class='box <?php echo $style.' '.$solid; ?>'>
	<div class='box-header with-border'>
		<h3 class='box-title'><?php echo $title; ?></h3>
	</div>
	<div class='box-body'>