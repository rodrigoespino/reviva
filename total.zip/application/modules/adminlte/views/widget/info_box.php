<div class='info-box'>
	<a href='<?php echo $url; ?>'>
		<span class='info-box-icon bg-<?php echo $color; ?>'><i class='<?php echo $icon; ?>'></i></span>
	</a>
	<div class='info-box-content'>
		<span class='info-box-text'><?php echo $label; ?></span>
		<span class='info-box-number'><?php echo $number; ?></span>
	</div>
</div>