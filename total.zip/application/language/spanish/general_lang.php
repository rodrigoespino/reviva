<?php

	$lang['website_name'] = "Mi sitio web";
	$lang['current_language'] = "Idioma actual";
	
	// Menu
	$lang['home'] = "Home";
	$lang['about_us'] = "About Us";
	$lang['contact_us'] = "Contáctenos";
	$lang['example'] = "Ejemplo";

	// General terms
	$lang['address'] = "Dirección";
	$lang['email'] = "Correo";
	$lang['phone'] = "Teléfono";
	$lang['remarks'] = "Observaciones";
	$lang['subject'] = "Asunto";
	$lang['message'] = "Mensaje";
	
	// Actions
	$lang['sign_up'] = "Registrarse";
	$lang['login'] = "Conectarse";
	$lang['search'] = "Buscar";
	$lang['send'] = "Enviar";
	$lang['download'] = "Descargar";
	$lang['read_more'] = "Lee mas";