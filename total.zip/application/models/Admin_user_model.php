<?php 

class Admin_user_model extends MY_Model {
}